// this #ifndef stops this file
// from being included mored than
// once by the compiler. 
#ifndef _LINESENSOR_H
#define _LINESENSOR_H

#define LS_LEFT_PIN A0
#define LS_CENTRE_PIN A2
#define LS_RIGHT_PIN A3

# define IR_LED_POWER 11 // IR LED power (EMIT)

// 使用传感器的数量
#define NB_LS_PINS 3

// 黑色、白色的值
int white_value;
int black_value;

int which;

float e_line;

float sensor_global[NB_LS_PINS];
int ls_pin[NB_LS_PINS] = {LS_LEFT_PIN, LS_CENTRE_PIN, LS_RIGHT_PIN};

// 存放传感器读取到的值
unsigned long sensor_read[NB_LS_PINS];

// Class to operate the linesensor(s).
class LineSensor_c {
  public:
  
    // Constructor, must exist.
    LineSensor_c() {

    } 

    void initialise() {

      // EMIT pin mode as an OUTPUT
      // To switch off IR_LED_POWER, set INPUT
      pinMode(IR_LED_POWER, OUTPUT);

      // To enable the IR LEDs for the line sensors
      digitalWrite(IR_LED_POWER, HIGH);

    }

    void Charge_Capacitor() {

      pinMode(LS_LEFT_PIN, OUTPUT);
      digitalWrite(LS_LEFT_PIN, HIGH);

      pinMode(LS_RIGHT_PIN, OUTPUT);
      digitalWrite(LS_RIGHT_PIN, HIGH);

      pinMode(LS_CENTRE_PIN, OUTPUT);
      digitalWrite(LS_CENTRE_PIN, HIGH);

      // Tiny delay for capacitor to charge.
      delayMicroseconds(10);

    }

    void Set_Sensors_INPUT() {// Set the sensor to INPUT

      for (which = 0; which < NB_LS_PINS; which++) {
      pinMode(ls_pin[which], INPUT);
      sensor_read[which] = 0;
      }
    }

    void doParallelSensorRead() {
    
    int timeout = 5000;
    unsigned long start_time;
    unsigned long current_time;


    // 定义计数器查看几个传感器完成了读取
    // Remaining == 0 will mean all sensors complete.
    int remaining = NB_LS_PINS;

    // Charge the capacitor and set pins OUTPUT and HIGH
    Charge_Capacitor();

    // Record start time
    start_time = micros();

    // Set the sensor to INPUT
    Set_Sensors_INPUT();

    while(remaining > 0) {

      for(which = 0; which < NB_LS_PINS; which++) {

        // Get current time
        current_time = micros();

        // Determine elapsed time
        unsigned long elapsed_time = current_time - start_time;

        // If digitalRead() returns LOW, the sensor completes the reading
        if(digitalRead(ls_pin[which]) == LOW) {

          // Check if this sensor has had a previous value of elapsed time 
          // stored before.
          // We only want to store the EARLIEST 
          // elapsed time, not store subsequent values.
          if(sensor_read[which] == 0) { // NULLL
            
            sensor_read[which] = elapsed_time;

            // !!! Assign the local variable sensor_read to the global variable sensor_global
            sensor_global[which] = sensor_read[which];

            remaining--;

          }

          if (elapsed_time >= timeout) {

            // Set an appropriate sensor_read[which] value to indicate a timeout.
            sensor_read[which] = timeout;
            remaining = 0;

          }

        } // end of if(digitalRead)

      } // end of for() looping through each sensor

    } // end of while( remaining > 0 )

    // Report total execution time
    for (which = 0; which < NB_LS_PINS; which++) {

      // Serial.print(sensor_read[which]);
      // Serial.print(", ");

    }
      // Serial.print("\n");

  }

    float getLineError() {

      float w_left = sensor_global[0];
      float w_right = sensor_global[2];
      float w_middle = sensor_global[1];
      float sum;

      // Calculated error signal
      sum = w_left + w_right + w_middle;

      w_right = w_right / sum;
      w_left = w_left / sum;
      w_middle = w_middle / sum;

      w_right = (float)w_right + 0.5 * (float)w_middle;
      w_left  = (float)w_left + 0.5 * (float)w_middle;
      e_line  = w_left - w_right + 0.01;

      // Serial.print("e_line: ");
      // Serial.println(e_line);

      // return line error
      return e_line;

    }

};



#endif
