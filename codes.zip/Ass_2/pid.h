// this #ifndef stops this file
// from being included mored than
// once by the compiler. 
#ifndef _PID_H
#define _PID_H

// Class to contain generic PID algorithm.
class PID_c {
  public:

  // PID update variables
  float last_error;
  float p_term; // p-term
  float i_term;
  float d_term;
  float i_sum;
  float feedback;

  // To store gains
  float p_gain;
  float i_gain;
  float d_gain;

  // To determine time elapsed
  unsigned long ms_last_ts;

  float y_t; // measurement: weighted-measurement calculation 的输出。[-1.0 : +1.0]
  float r_t; // demand: 设置为 0，希望线位于传感器中央
  float e_t; // error signal：measurement 和 demand 的差

  float K_p = 255; // proportional gain: 设为电机最大功率
  
  // Constructor, must exist.
  PID_c() {

  }

  void initialise(float kp, float ki, float kd) {

    feedback = 0;
    last_error = 0;
    p_term = 0;
    i_term = 0;
    d_term = 0;

    p_gain = kp;
    i_gain = ki;
    d_gain = kd;

    ms_last_ts = millis();

  }

  // Resets variables including the timestamp
  void reset() {

    p_term = 0;
    i_term = 0;
    d_term = 0;

    last_error = 0;
    feedback = 0;
    ms_last_ts = millis();

  }

  float update(float demand, float measurement) {

    float error;
    unsigned long ms_now_ts;
    unsigned long ms_dt;
    float float_dt;
    float diff_error;

    // Grab time to calc elapsed time
    ms_now_ts = millis();
    ms_dt = ms_now_ts - ms_last_ts;

    // Update ms_last_ts
    ms_last_ts = millis();

    float_dt = (float)ms_dt;

    // dt 不能为 0，因为它要作为除数
    // 若 dt 为 0，则检查 feedback 的状态
    if(float_dt == 0) return feedback;

    // Calc error signal
    error = demand - measurement;

    // P-term：误差比例控制，差得越多，输出值越大
    p_term = p_gain * error;

    // discrete integration 离散积分
    i_sum = i_sum + (error * float_dt);

    // i_term: 积分项消除静态误差
    i_term = i_gain * i_sum;

    // d_term = kp * t：微分阻尼项
    // 注意符号，有时可能为负
    // 取决于 error signal 与 system 的关系
    diff_error = (error - last_error) / float_dt;
    last_error = error;
    d_term = diff_error * d_gain;

    feedback = p_term + i_term + d_term;

    return feedback;

  }



};



#endif
