// this #ifndef stops this file
// from being included mored than
// once by the compiler. 

#ifndef _KINEMATICS_H
#define _KINEMATICS_H

struct Result_xy
{

  float xx; // x坐标
  float yy; // y坐标
  float t; // theta

};

float dtance; 
float x_i;
float y_i; 

float theta;

// Class to track robot position.
class Kinematics_c {
  public:

  //notes;
  float r = 16;//mm
  // half the robot
  float l = 43.5;//mm
  //c= 2*pai*r =100.5mm
  //c'= 2*pai*l = 274mm
  float yiquanr = 100.5; // 
  float yiquanl = 274;

  float count_e0_last;
  float count_e1_last;    
    
  long diff_e0;
  long diff_e1;

  float dright;
  float dleft;
  float dth;

    // Constructor, must exist.
    Kinematics_c() {

    } 
    
    // Use this function to update
    // your kinematics
    struct Result_xy update() {

    diff_e0 = count_e0 - count_e0_last;
    diff_e1 = count_e1 - count_e1_last;  
    count_e0_last = count_e0;
    count_e1_last = count_e1;

    dright =  yiquanr * diff_e0 / 361.8 ; // 右车轮的变化的距离
    dleft  =  yiquanr * diff_e1 / 361.8 ; // 左车轮的变化的距离
    dth    = (dleft + dright) / 361.8 * PI; // 6.28：2PI
    // dth    = (dright - dleft) / 358.8 * 2 * PI; // 6.28：2PI
   

    x_i += 0.5 * (dright + dleft) * cos(0.5 * dth + theta); // cos, sin：弧度
    y_i += 0.5 * (dleft + dright) * sin(0.5 * dth + theta);
    theta += dth;
    //another kinematics method code
    // x_i += 0.5 * (dright + dleft) * cos(theta);
    // y_i += 0.5 * (dright + dleft) * sin(theta);
    // theta = theta + dth;

    struct Result_xy res_xy;
    res_xy.xx = x_i;
    res_xy.yy = y_i;
    res_xy.t = theta;
    return res_xy;
      
}
    

};



#endif
