// this #ifndef stops this file
// from being included mored than
// once by the compiler. 
#ifndef _MOTORS_H
#define _MOTORS_H

# define L_PWM_PIN 10  // 
# define L_DIR_PIN 16 // direction of rotation of the left motor
# define R_PWM_PIN 9  // 
# define R_DIR_PIN 15 // direction of rotation of the right motor

# define FWD LOW  // forward: low
# define REV HIGH  // backward: high

// Class to operate the motor(s).
class Motors_c {

public:

  float time;
  float turn_pwm;

    // Constructor, must exist.
    Motors_c() {

    } 

    // Use this function to 
    // initialise the pins and 
    // state of your motor(s).
    void initialise() {

      // Initialisation of the motor drive IO to output mode
      pinMode(L_PWM_PIN, OUTPUT);
      pinMode(L_DIR_PIN, OUTPUT);
      pinMode(R_PWM_PIN, OUTPUT);
      pinMode(R_DIR_PIN, OUTPUT);

    }

    void setMotorsPWM(float l_pwm, float r_pwm) {
      if(l_pwm <= 0 && r_pwm >= 0) {
        // 初始化左电机为后退方向，右电机为前进方向
        digitalWrite(L_DIR_PIN, REV);
        digitalWrite(R_DIR_PIN, FWD);

        analogWrite(L_PWM_PIN, abs(l_pwm)); // Writes an analog value (PWM wave) to a pin. 
        analogWrite(R_PWM_PIN, abs(r_pwm)); // Minimal: 15

        delay(10);

      } else if(l_pwm >= 0 && r_pwm <= 0) {
        
        // 初始化左电机为前进方向，右电机为后退方向
        digitalWrite(L_DIR_PIN, FWD);
        digitalWrite(R_DIR_PIN, REV);

        analogWrite(L_PWM_PIN, abs(l_pwm)); // Writes an analog value (PWM wave) to a pin. 
        analogWrite(R_PWM_PIN, abs(r_pwm)); // Minimal: 15

        delay(10);

      } else {

        // 初始化左电机和右电机为前进方向
        digitalWrite(L_DIR_PIN, REV);
        digitalWrite(R_DIR_PIN, REV);

        analogWrite(L_PWM_PIN, abs(l_pwm)); // Writes an analog value (PWM wave) to a pin. 
        analogWrite(R_PWM_PIN, abs(r_pwm)); // Minimal: 15

        delay(10);

      }

    }

    // Write a function to operate
    void go_forward(float time) {

      // 初始化电机为前进方向
      digitalWrite(L_DIR_PIN, FWD);
      digitalWrite(R_DIR_PIN, FWD);
      
      analogWrite(L_PWM_PIN, 30); // Writes an analog value (PWM wave) to a pin. 
      analogWrite(R_PWM_PIN, 30); // Minimal: 15

      // A small delay to prevent this for now
      delay(time);

    }

    void turn_around(float time) { // 0.85: 90°， 1.7：180°

      // 初始化左电机为后退方向，右电机为前进方向
      digitalWrite(L_DIR_PIN, REV);
      digitalWrite(R_DIR_PIN, FWD);
      
      analogWrite(L_PWM_PIN, 21); // Writes an analog value (PWM wave) to a pin. 
      analogWrite(R_PWM_PIN, 20); // Minimal: 15

      // A small delay to prevent this for now
      delay(1000 * time);

    }

    void break_(float time) {

      analogWrite(L_PWM_PIN, 0); // Writes an analog value (PWM wave) to a pin. 
      analogWrite(R_PWM_PIN, 0); // Minimal: 15

      // A small delay
      delay(1000 * time);

    }

    void follow_line(float turn_pwm) {  // 正：左转；负：右转

      go_forward(30);

      setMotorsPWM(-turn_pwm, turn_pwm);
      

    }

};



#endif
